#include <stdio.h>
#include <iostream>

int main() {
	char cs = 'C';
	char ct = 'C';

	std::cout << (cs ^ ct);

	return 0;
}
